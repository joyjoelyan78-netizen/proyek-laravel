

<?php $__env->startSection('content'); ?>

<link rel="stylesheet"
href="<?php echo e(asset('css/produk.css')); ?>">

<div class="page-header">

    <h1>Data Produk</h1>

    <a href="/admin/produk/create" class="btn-primary">
        + Tambah Produk
    </a>

</div>

<div class="card-table">

    <table>

        <thead>
            <tr>
                <th>Foto</th>
                <th>Kode</th>
                <th>Nama Produk</th>
                <th>Kategori</th>
                <th>Berat</th>
                <th>Garansi</th>
                <th>Status</th>
                <th width="190">Aksi</th>
            </tr>
        </thead>

        <tbody>

        <?php $__currentLoopData = $produk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <tr>

            <td width="90">

                <?php if($p->gambar_produk): ?>

                    <img src="<?php echo e(asset('storage/'.$p->gambar_produk)); ?>"
                         class="product-image">

                <?php else: ?>

                    -

                <?php endif; ?>

            </td>

            <td>
                <strong><?php echo e($p->kode_produk); ?></strong>
            </td>

            <td>
                <strong><?php echo e($p->nama_produk); ?></strong>
                <br>

                <small class="text-secondary">
                    <?php echo e($p->seri_produk); ?>

                </small>
            </td>

            <td>

                <span class="badge-role">
                    <?php echo e($p->kategori->nama_kategori); ?>

                </span>

            </td>

            <td><?php echo e($p->berat); ?> Kg</td>

            <td><?php echo e($p->masa_garansi_bulan); ?> Bulan</td>

            <td>

                <?php if($p->status_produk == 'aktif'): ?>

                    <span class="badge-active">
                        Aktif
                    </span>

                <?php else: ?>

                    <span class="badge-nonactive">
                        Nonaktif
                    </span>

                <?php endif; ?>

            </td>

            <td>

                <div class="action-buttons">

                    <a href="/admin/produk/<?php echo e($p->id_produk); ?>/edit"
                       class="btn-edit">

                        Edit

                    </a>

                    <form action="/admin/produk/<?php echo e($p->id_produk); ?>"
                          method="POST">

                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>

                        <button class="btn-delete"
                                onclick="return confirm('Hapus produk?')">

                            Hapus

                        </button>

                    </form>

                </div>

            </td>

        </tr>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </tbody>

    </table>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\vesca_baru\resources\views/backend/produk/index.blade.php ENDPATH**/ ?>