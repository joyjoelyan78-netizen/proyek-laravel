

<?php $__env->startSection('content'); ?>

<link rel="stylesheet" href="/css/produk.css">

<?php
    // Controller semuaProduk() mengirim $kategori, tetapi kategori() mengirim $allKategori.
    // Dua-duanya ditangani di sini supaya halaman tidak error.
    $daftarKategori = $kategori ?? $allKategori ?? collect();

    $ikonKategori = function ($nama) {
        $n = strtolower($nama);
        if (str_contains($n, 'alumin')) return 'fa-cubes';
        if (str_contains($n, 'zinc') || str_contains($n, 'seng')) return 'fa-cube';
        return 'fa-cog';
    };
?>

<div class="pk-page">

    
    
    <section class="pk-hero"
             style="--hero-img: url('/images/produk-hero.jpg')">
        <div class="pk-wrap">
            <div class="pk-hero__content">
                <h1>Produk <span>Berkualitas Tinggi</span></h1>
                <p>
                    Anoda berkualitas tinggi dengan standar internasional
                    untuk performa maksimal dan umur pakai yang lebih lama
                    di lingkungan air laut maupun air tawar.
                </p>
                <a href="<?php echo e(route('hubungi')); ?>" class="pk-btn-outline">
                    Hubungi Kami <i class="fas fa-phone"></i>
                </a>
            </div>
        </div>
    </section>

    
    <section class="pk-section">
        <div class="pk-wrap">

            <p class="pk-label">Kategori Produk</p>
            <h2 class="pk-title">Solusi Proteksi Katodik untuk Berbagai Kebutuhan</h2>

            
            <nav class="pk-tabs" aria-label="Kategori produk">

                <a href="<?php echo e(route('produk')); ?>"
                   class="pk-tab <?php echo e(isset($kategoriData) ? '' : 'is-active'); ?>">
                    <i class="fas fa-th-large"></i> Semua Produk
                </a>

                <?php $__currentLoopData = $daftarKategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(route('produk.kategori', $k->slug)); ?>"
                       class="pk-tab <?php echo e(isset($kategoriData) && $kategoriData->id_kategori == $k->id_kategori ? 'is-active' : ''); ?>">
                        <i class="fas <?php echo e($ikonKategori($k->nama_kategori)); ?>"></i>
                        <?php echo e($k->nama_kategori); ?>

                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </nav>

            
            <?php if(request('search')): ?>
                <p class="pk-result">
                    Hasil pencarian "<strong><?php echo e(request('search')); ?></strong>"
                    &middot; <?php echo e($products->count()); ?> produk
                </p>
            <?php elseif(isset($kategoriData)): ?>
                <p class="pk-result">
                    Kategori <strong><?php echo e($kategoriData->nama_kategori); ?></strong>
                    &middot; <?php echo e($products->count()); ?> produk
                </p>
            <?php endif; ?>

            
            <div class="pk-grid">

                <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                    <a href="<?php echo e(route('produk.detail', $product->slug)); ?>" class="pk-card">

                        <div class="pk-card__img">
                            <?php if($product->gambar_produk): ?>
                                <img src="/storage/<?php echo e($product->gambar_produk); ?>"
                                     alt="<?php echo e($product->nama_produk); ?>"
                                     loading="lazy">
                            <?php else: ?>
                                <div class="pk-card__noimg"><i class="fas fa-image"></i></div>
                            <?php endif; ?>
                        </div>

                        <div class="pk-card__body">
                            <h3><?php echo e($product->nama_produk); ?></h3>
                            <p><?php echo e(\Illuminate\Support\Str::limit(strip_tags($product->deskripsi), 90)); ?></p>
                            <span class="pk-card__more">
                                Selengkapnya <i class="fas fa-arrow-right"></i>
                            </span>
                        </div>

                    </a>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                    <p class="pk-empty">Produk belum tersedia.</p>

                <?php endif; ?>

            </div>

            
            <div class="pk-features">
                <div class="pk-feature">
                    <i class="fas fa-shield-alt"></i>
                    <div><strong>Kualitas Terjamin</strong><span>Sesuai standar NACE TM</span></div>
                </div>
                <div class="pk-feature">
                    <i class="fas fa-award"></i>
                    <div><strong>Pengalaman 25+ Tahun</strong><span>Sejak 1997 melayani industri</span></div>
                </div>
                <div class="pk-feature">
                    <i class="fas fa-hands-helping"></i>
                    <div><strong>Solusi Profesional</strong><span>Teknisi berpengalaman</span></div>
                </div>
                <div class="pk-feature">
                    <i class="fas fa-handshake"></i>
                    <div><strong>Layanan Terpercaya</strong><span>Kepuasan pelanggan prioritas kami</span></div>
                </div>
            </div>

            
            <div class="pk-cta">
                <i class="fas fa-headset pk-cta__icon"></i>
                <div class="pk-cta__text">
                    <h3>Butuh Bantuan atau konsultasi lebih lanjut ?</h3>
                    <p>Tim kami siap membantu Anda menemukan solusi perlindungan korosi terbaik</p>
                </div>
                <a href="<?php echo e(route('hubungi')); ?>" class="pk-btn-outline">
                    Hubungi Kami <i class="fas fa-phone"></i>
                </a>
            </div>

        </div>
    </section>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\vesca_baru\resources\views/frontend/produk/index.blade.php ENDPATH**/ ?>