<?php $__env->startSection('content'); ?>

<link rel="stylesheet" href="/css/layanan-form.css">

<?php
    $wa = preg_replace('/\D+/', '', (string) config('vesca.whatsapp'));
    $alu = $bahan['aluminium'];
    $zn  = $bahan['zinc'];
?>

<section class="lf-page">

    <div class="lf-container">

        
        <div class="lf-hero">

            <h1>Konsultasi &amp; Spesifikasi Teknis</h1>

            <p>
                Lihat data teknis lengkap anoda VESCA, mulai dari perbandingan
                Zinc dan Aluminium, tabel ukuran semua tipe, sampai sertifikasi.
                Masih ragu memilih? Kirim pertanyaan ke tim teknis kami.
            </p>

        </div>

        
        <div class="lf-quicknav">
            <a href="#panduan">Zinc atau Aluminium?</a>
            <a href="#spesifikasi">Tabel Spesifikasi</a>
            <a href="#material">Komposisi Material</a>
            <a href="#sertifikasi">Sertifikasi</a>
            <a href="#faq">Pertanyaan Umum</a>
            <a href="#form-konsultasi">Kirim Pertanyaan</a>
        </div>


        
        <div class="lf-block" id="panduan">

            <h2>Zinc atau Aluminium?</h2>

            <p class="lf-lead">
                Keduanya adalah anoda korban (sacrificial anode): anoda yang terkikis
                lebih dulu supaya badan kapal atau struktur baja tetap terlindungi.
                Berikut data performa nominal dari katalog kami.
            </p>

            <div class="lf-compare">

                <div class="lf-compare-card">
                    <h3><?php echo e($alu['nama']); ?></h3>
                    <p class="lf-bahan-ringkasan" style="margin:0;"><?php echo e($alu['ringkasan']); ?></p>
                </div>

                <div class="lf-compare-card">
                    <h3><?php echo e($zn['nama']); ?></h3>
                    <p class="lf-bahan-ringkasan" style="margin:0;"><?php echo e($zn['ringkasan']); ?></p>
                </div>

            </div>

            <div class="lf-table-wrap" style="margin-top:22px;">

                <table class="lf-table lf-banding">

                    <thead>
                        <tr>
                            <th>Data performa nominal</th>
                            <th><?php echo e($alu['nama']); ?></th>
                            <th><?php echo e($zn['nama']); ?></th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php $__currentLoopData = $alu['performa']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $label => $nilai): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($label); ?></td>
                                <td><?php echo e($nilai); ?></td>
                                <td><?php echo e($zn['performa'][$label] ?? '-'); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>

                </table>

            </div>

            <p class="lf-baca">
                <strong>Cara membacanya:</strong>
                kapasitas listrik seperti &quot;isi baterai&quot; per kilogram anoda, makin besar
                makin banyak arus yang bisa diberikan. Laju konsumsi menunjukkan berapa kilogram
                anoda yang habis untuk setiap ampere arus selama setahun, makin kecil makin awet
                per kilogramnya.
            </p>

            <div class="lf-disclaimer">
                Ini data nominal dari katalog. Pilihan akhir bergantung pada kondisi air,
                ukuran kapal atau struktur, dan lama proteksi yang diinginkan. Tim teknis kami
                bisa membantu menentukannya, silakan kirim pertanyaan di bawah.
            </div>

        </div>


        
        <div class="lf-block" id="spesifikasi">

            <h2>Tabel Spesifikasi Produk</h2>

            <p class="lf-lead">
                Pilih jenis anoda, lalu klik <strong>Minta penawaran</strong> di baris tipe yang Anda butuhkan.
                Geser tabel ke samping jika terpotong di layar kecil.
            </p>

            <div class="lf-tabs" role="tablist">
                <button type="button" class="lf-tab active" data-panel="panel-aluminium">Aluminium Anode</button>
                <button type="button" class="lf-tab" data-panel="panel-zinc">Zinc Anode</button>
            </div>

            <?php $__currentLoopData = ['aluminium', 'zinc']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kodeBahan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <div class="lf-panel <?php echo e($kodeBahan === 'aluminium' ? 'active' : ''); ?>" id="panel-<?php echo e($kodeBahan); ?>">

                    <?php $__currentLoopData = $seriList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kodeSeri => $seri): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <?php if($seri['bahan'] === $kodeBahan): ?>

                            <div class="lf-kategori-title" id="seri-<?php echo e($kodeSeri); ?>"><?php echo e($seri['nama']); ?></div>

                            <p class="lf-seri-desc"><?php echo e($seri['deskripsi']); ?></p>

                            <div class="lf-table-wrap">

                                <table class="lf-table">

                                    <thead>
                                        <tr>
                                            <?php $__currentLoopData = $seri['kolom']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $judul): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <th><?php echo e($judul); ?></th>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <th></th>
                                        </tr>
                                    </thead>

                                    <tbody>

                                        <?php $__currentLoopData = $seri['baris']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $baris): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <?php $__currentLoopData = $baris; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $nilai): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <td class="<?php echo e($i === 0 ? 'lf-kode' : ''); ?>"><?php echo e($nilai); ?></td>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <td class="lf-aksi">
                                                    <a href="<?php echo e(route('penawaran.index', ['seri' => $kodeSeri, 'tipe' => $baris[0]])); ?>">
                                                        Minta penawaran
                                                    </a>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </tbody>

                                </table>

                            </div>

                        <?php endif; ?>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>


        
        <div class="lf-block" id="material">

            <h2>Komposisi Material</h2>

            <p class="lf-lead">Komposisi paduan anoda sesuai katalog.</p>

            <div class="lf-komposisi">

                <?php $__currentLoopData = [$alu, $zn]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <div>

                        <h3><?php echo e($b['nama']); ?></h3>

                        <div class="lf-table-wrap">

                            <table class="lf-table">

                                <thead>
                                    <tr>
                                        <?php $__currentLoopData = $b['komposisi_kolom']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $judul): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <th><?php echo e($judul); ?></th>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tr>
                                </thead>

                                <tbody>
                                    <?php $__currentLoopData = $b['komposisi']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $baris): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <?php $__currentLoopData = $baris; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nilai): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <td><?php echo e($nilai); ?></td>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>

                            </table>

                        </div>

                    </div>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>

        </div>


        
        <div class="lf-block" id="sertifikasi">

            <h2>Sertifikasi &amp; Kontrol Kualitas</h2>

            <p class="lf-lead">
                Sertifikat yang tercantum di katalog PT Vescarindo Utama.
                Komposisi material dianalisis dengan mesin spectrometer dan
                potensial anoda diuji, seperti didokumentasikan di katalog kami.
            </p>

            <div class="lf-sertifikat">

                <?php $__currentLoopData = $sertifikat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sert): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <div class="lf-sert-card">

                        <div class="lf-sert-lembaga"><?php echo e($sert['lembaga']); ?></div>

                        <h3><?php echo e($sert['judul']); ?></h3>

                        <dl>
                            <?php $__currentLoopData = $sert['detail']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $label => $nilai): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <dt><?php echo e($label); ?></dt>
                                <dd><?php echo e($nilai); ?></dd>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </dl>

                    </div>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>

        </div>


        
        <div class="lf-block lf-faq" id="faq">

            <h2>Pertanyaan Umum</h2>

            <p class="lf-lead">Jawaban singkat sebelum Anda mengirim pertanyaan.</p>

            <details>
                <summary>Apa yang perlu saya siapkan sebelum berkonsultasi?</summary>
                <p>
                    Jenis dan ukuran kapal (atau struktur), bagian yang ingin dilindungi,
                    serta kondisi air tempat beroperasi. Jika ada, sebutkan juga tipe anoda
                    yang terpasang saat ini.
                </p>
            </details>

            <details>
                <summary>Saya belum tahu tipe yang cocok. Apakah tetap bisa bertanya?</summary>
                <p>
                    Bisa. Cukup ceritakan kondisi kapal atau struktur Anda, lalu tim teknis
                    kami yang akan merekomendasikan seri dan tipenya.
                </p>
            </details>

            <details>
                <summary>Bagaimana jika ukuran yang saya butuhkan tidak ada di tabel?</summary>
                <p>
                    Tulis kebutuhan Anda di formulir
                    <a href="<?php echo e(route('penawaran.index')); ?>">Minta Penawaran Resmi</a>
                    dengan memilih &quot;ukuran khusus (custom)&quot;, atau sampaikan lewat formulir di bawah.
                </p>
            </details>

            <details>
                <summary>Berapa lama saya mendapat jawaban?</summary>
                <p>
                    Estimasi respon kami <?php echo e(config('vesca.sla_respon')); ?>, melalui email
                    atau WhatsApp sesuai kontak yang Anda isi.
                </p>
            </details>

            <details>
                <summary>Saya sudah tahu kebutuhannya dan ingin langsung meminta harga.</summary>
                <p>
                    Silakan gunakan formulir
                    <a href="<?php echo e(route('penawaran.index')); ?>">Minta Penawaran Resmi</a>.
                </p>
            </details>

        </div>


        
        <div class="lf-block" id="form-konsultasi">

            <h2>Kirim Pertanyaan ke Tim Teknis</h2>

            <p class="lf-lead">
                Isi data berikut. Kolom bertanda <span class="lf-req">*</span> wajib diisi.
            </p>

            <?php if($errors->any()): ?>

                <div class="lf-alert lf-alert-error">

                    Formulir belum lengkap. Mohon periksa kembali isian berikut:

                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>

                </div>

            <?php endif; ?>

            <form action="<?php echo e(route('konsultasi.store')); ?>" method="POST">

                <?php echo csrf_field(); ?>

                
                <div class="lf-hp" aria-hidden="true">
                    <label>Website</label>
                    <input type="text" name="website" tabindex="-1" autocomplete="off">
                </div>

                <div class="lf-grid-2">

                    <div class="lf-field <?php $__errorArgs = ['nama_pengirim'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                        <label for="nama_pengirim">Nama Lengkap <span class="lf-req">*</span></label>
                        <input type="text" id="nama_pengirim" name="nama_pengirim"
                               value="<?php echo e(old('nama_pengirim')); ?>"
                               placeholder="Nama Anda" required>
                        <?php $__errorArgs = ['nama_pengirim'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="lf-error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="lf-field <?php $__errorArgs = ['nama_perusahaan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                        <label for="nama_perusahaan">Nama Perusahaan</label>
                        <input type="text" id="nama_perusahaan" name="nama_perusahaan"
                               value="<?php echo e(old('nama_perusahaan')); ?>"
                               placeholder="PT / CV / instansi (jika ada)">
                        <?php $__errorArgs = ['nama_perusahaan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="lf-error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="lf-field <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                        <label for="email">Email <span class="lf-req">*</span></label>
                        <input type="email" id="email" name="email"
                               value="<?php echo e(old('email')); ?>"
                               placeholder="nama@perusahaan.com" required>
                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="lf-error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="lf-field <?php $__errorArgs = ['nomor_telepon'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                        <label for="nomor_telepon">Nomor Telepon / WhatsApp <span class="lf-req">*</span></label>
                        <input type="tel" id="nomor_telepon" name="nomor_telepon"
                               value="<?php echo e(old('nomor_telepon')); ?>"
                               placeholder="0812xxxxxxxx" required>
                        <?php $__errorArgs = ['nomor_telepon'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="lf-error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="lf-field <?php $__errorArgs = ['jenis_kapal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                        <label for="jenis_kapal">Jenis Kapal / Struktur <span class="lf-req">*</span></label>
                        <input type="text" id="jenis_kapal" name="jenis_kapal"
                               value="<?php echo e(old('jenis_kapal')); ?>"
                               placeholder="Contoh: tanker, tongkang, kapal feri, dermaga" required>
                        <?php $__errorArgs = ['jenis_kapal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="lf-error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="lf-field <?php $__errorArgs = ['ukuran_kapal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                        <label for="ukuran_kapal">Ukuran Kapal</label>
                        <input type="text" id="ukuran_kapal" name="ukuran_kapal"
                               value="<?php echo e(old('ukuran_kapal')); ?>"
                               placeholder="Contoh: panjang 60 m atau 3000 GT">
                        <?php $__errorArgs = ['ukuran_kapal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="lf-error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="lf-field <?php $__errorArgs = ['bagian_dilindungi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                        <label for="bagian_dilindungi">Bagian yang Ingin Dilindungi</label>
                        <select id="bagian_dilindungi" name="bagian_dilindungi">
                            <option value="">-- Pilih bagian --</option>
                            <?php $__currentLoopData = \App\Models\KonsultasiTeknis::BAGIAN_DILINDUNGI; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bagian): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($bagian); ?>" <?php if(old('bagian_dilindungi') === $bagian): echo 'selected'; endif; ?>>
                                    <?php echo e($bagian); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php $__errorArgs = ['bagian_dilindungi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="lf-error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="lf-field <?php $__errorArgs = ['kondisi_air'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                        <label for="kondisi_air">Kondisi Air <span class="lf-req">*</span></label>
                        <select id="kondisi_air" name="kondisi_air" required>
                            <option value="">-- Pilih kondisi air --</option>
                            <?php $__currentLoopData = \App\Models\KonsultasiTeknis::KONDISI_AIR; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nilai => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($nilai); ?>" <?php if(old('kondisi_air') === $nilai): echo 'selected'; endif; ?>>
                                    <?php echo e($label); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php $__errorArgs = ['kondisi_air'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="lf-error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                </div>

                <div class="lf-field <?php $__errorArgs = ['produk_diminati'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                    <label for="produk_diminati">Seri Produk yang Diminati (opsional)</label>
                    <select id="produk_diminati" name="produk_diminati">
                        <option value="">-- Pilih jika sudah tahu --</option>
                        <?php $__currentLoopData = $pilihanSeri; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kodeSeri => $labelSeri): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($kodeSeri); ?>"
                                <?php if(old('produk_diminati', $seriTerpilih) === $kodeSeri): echo 'selected'; endif; ?>>
                                <?php echo e($labelSeri); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['produk_diminati'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="lf-error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="lf-field <?php $__errorArgs = ['pertanyaan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                    <label for="pertanyaan">Pertanyaan / Kebutuhan Anda <span class="lf-req">*</span></label>
                    <textarea id="pertanyaan" name="pertanyaan" rows="5"
                              placeholder="Ceritakan kondisi kapal, masalah korosi yang dihadapi, atau hal yang ingin Anda ketahui"
                              required><?php echo e(old('pertanyaan')); ?></textarea>
                    <?php $__errorArgs = ['pertanyaan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="lf-error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="lf-actions" style="justify-content:flex-start;margin-top:8px;">

                    <button type="submit" class="lf-btn">
                        <i class="fas fa-paper-plane"></i> Kirim Pertanyaan
                    </button>

                    <?php if($wa): ?>
                        <a class="lf-btn lf-btn-wa"
                           href="https://wa.me/<?php echo e($wa); ?>?text=<?php echo e(rawurlencode('Halo PT Vescarindo Utama, saya ingin berkonsultasi mengenai anoda untuk kapal saya.')); ?>"
                           target="_blank" rel="noopener">
                            <i class="fab fa-whatsapp"></i> Chat via WhatsApp
                        </a>
                    <?php endif; ?>

                </div>

            </form>

            <div class="lf-kontak-cta">

                <span><strong>Atau hubungi langsung:</strong></span>

                <?php $__currentLoopData = config('vesca.telepon'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($tel): ?>
                        <a href="tel:<?php echo e(preg_replace('/[^0-9+]/', '', $tel)); ?>">
                            <i class="fas fa-phone"></i> <?php echo e($tel); ?>

                        </a>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php if(config('vesca.email')): ?>
                    <a href="mailto:<?php echo e(config('vesca.email')); ?>">
                        <i class="fas fa-envelope"></i> <?php echo e(config('vesca.email')); ?>

                    </a>
                <?php endif; ?>

            </div>

        </div>

    </div>

</section>

<script>
(function () {

    var tabs   = document.querySelectorAll('.lf-tab');
    var panels = document.querySelectorAll('.lf-panel');

    tabs.forEach(function (tab) {

        tab.addEventListener('click', function () {

            tabs.forEach(function (t) { t.classList.remove('active'); });
            panels.forEach(function (p) { p.classList.remove('active'); });

            tab.classList.add('active');
            document.getElementById(tab.getAttribute('data-panel')).classList.add('active');
        });
    });

})();
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\vesca_baru\resources\views/frontend/konsultasi/index.blade.php ENDPATH**/ ?>