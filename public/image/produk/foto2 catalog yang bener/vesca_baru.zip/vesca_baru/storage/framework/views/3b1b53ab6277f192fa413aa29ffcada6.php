

<?php $__env->startSection('content'); ?>

<link rel="stylesheet" href="<?php echo e(asset('css/produk.css')); ?>">

<div class="page-header">
    <h1>Edit Produk</h1>
</div>

<?php if($errors->any()): ?>
<div class="alert-danger-custom">
    <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>
<?php endif; ?>

<form action="/admin/produk/<?php echo e($produk->id_produk); ?>"
      method="POST"
      enctype="multipart/form-data">

    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>

    <div class="card-form">

        <h3>Informasi Produk</h3>

        <label>Kode Produk</label>
        <input type="text"
               name="kode_produk"
               value="<?php echo e(old('kode_produk', $produk->kode_produk)); ?>"
               required>

        <label>Nama Produk</label>
        <input type="text"
               name="nama_produk"
               value="<?php echo e(old('nama_produk', $produk->nama_produk)); ?>"
               required>

        <label>Seri Produk</label>
        <input type="text"
               name="seri_produk"
               value="<?php echo e(old('seri_produk', $produk->seri_produk)); ?>">

        <label>Kategori Produk</label>
        <select name="id_kategori" required>

            <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <option value="<?php echo e($k->id_kategori); ?>"
                    <?php echo e($produk->id_kategori == $k->id_kategori ? 'selected' : ''); ?>>

                    <?php echo e($k->nama_kategori); ?>


                </option>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </select>

        <label>Deskripsi</label>
        <textarea name="deskripsi"><?php echo e(old('deskripsi', $produk->deskripsi)); ?></textarea>

    </div>

    <div class="card-form">

        <h3>Spesifikasi Produk</h3>

        <label>Berat (Kg)</label>
        <input type="number"
               step="0.01"
               name="berat"
               value="<?php echo e(old('berat', $produk->berat)); ?>">

        <label>Dimensi</label>
        <input type="text"
               name="dimensi"
               value="<?php echo e(old('dimensi', $produk->dimensi)); ?>">

        <label>Standar Kualitas</label>
        <input type="text"
               name="standar_kualitas"
               value="<?php echo e(old('standar_kualitas', $produk->standar_kualitas)); ?>">

        <label>Lingkungan Operasi</label>
        <textarea name="lingkungan_operasi"><?php echo e(old('lingkungan_operasi', $produk->lingkungan_operasi)); ?></textarea>

        <label>Komposisi Material</label>
        <textarea name="komposisi_material"><?php echo e(old('komposisi_material', $produk->komposisi_material)); ?></textarea>

    </div>

    <div class="card-form">

        <h3>Produksi & Garansi</h3>

        <label>Tanggal Produksi</label>
        <input type="date"
               name="tanggal_produksi"
               value="<?php echo e(old('tanggal_produksi', $produk->tanggal_produksi)); ?>">

        <label>Masa Garansi (Bulan)</label>
        <input type="number"
               name="masa_garansi_bulan"
               value="<?php echo e(old('masa_garansi_bulan', $produk->masa_garansi_bulan)); ?>">

        <label>Catatan PPN</label>
        <input type="text"
               name="catatan_ppn"
               value="<?php echo e(old('catatan_ppn', $produk->catatan_ppn)); ?>">

        <label>Link WhatsApp</label>
        <input type="text"
               name="link_whatsapp"
               value="<?php echo e(old('link_whatsapp', $produk->link_whatsapp)); ?>">

    </div>

    <div class="card-form">

        <h3>Media Produk</h3>

        <label>Gambar Produk</label>
        <input type="file" name="gambar_produk">

        <?php if($produk->gambar_produk): ?>

            <img
                src="<?php echo e(asset('storage/'.$produk->gambar_produk)); ?>"
                alt="<?php echo e($produk->nama_produk); ?>"
                class="product-preview">

        <?php endif; ?>

        <label>Status Produk</label>

        <select name="status_produk">

            <option value="aktif"
                <?php echo e($produk->status_produk == 'aktif' ? 'selected' : ''); ?>>
                Aktif
            </option>

            <option value="nonaktif"
                <?php echo e($produk->status_produk == 'nonaktif' ? 'selected' : ''); ?>>
                Nonaktif
            </option>

        </select>

    </div>

    <div class="form-footer">

        <a href="/admin/produk"
           class="btn-back">
            Kembali
        </a>

        <button type="submit"
                class="btn-primary">
            Update Produk
        </button>

    </div>

</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\vesca_baru\resources\views/backend/produk/edit.blade.php ENDPATH**/ ?>