

<?php $__env->startSection('content'); ?>

<link rel="stylesheet"
href="<?php echo e(asset('css/kategori-produk.css')); ?>">

<div class="page-header">

    <h1>Kategori Produk</h1>

    <a href="/admin/kategori-produk/create"
       class="btn-primary">

       + Tambah Kategori

    </a>

</div>

<div class="card-table">

    <table>

        <thead>
            <tr>
                <th width="80">No</th>
                <th>Nama Kategori</th>
                <th width="190">Aksi</th>
            </tr>
        </thead>

        <tbody>

        <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <tr>

            <td><?php echo e($loop->iteration); ?></td>

            <td>

                <strong><?php echo e($k->nama_kategori); ?></strong>

            </td>

            <td>

                <div class="action-buttons">

                    <a href="/admin/kategori-produk/<?php echo e($k->id_kategori); ?>/edit"
                       class="btn-edit">

                       Edit

                    </a>

                    <form action="/admin/kategori-produk/<?php echo e($k->id_kategori); ?>"
                          method="POST">

                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>

                        <button class="btn-delete"
                                onclick="return confirm('Hapus kategori?')">

                            Hapus

                        </button>

                    </form>

                </div>

            </td>

        </tr>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </tbody>

    </table>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\vesca_baru\resources\views/backend/kategori/index.blade.php ENDPATH**/ ?>