

<?php $__env->startSection('content'); ?>

<link rel="stylesheet"
href="<?php echo e(asset('css/teknisi.css')); ?>">

<div class="page-header">

    <div>
        <h1>Data Teknisi</h1>
    </div>

    <a href="<?php echo e(route('teknisi.create')); ?>"
       class="btn-primary">

        + Tambah Teknisi

    </a>

</div>

<div class="card-table">

    <table>

        <thead>

            <tr>

                <th>No</th>
                <th>Nama Teknisi</th>
                <th>Email</th>
                <th>Nomor Telepon</th>
                <th>Status</th>
                <th width="170">Aksi</th>

            </tr>

        </thead>

        <tbody>

            <?php $__empty_1 = true; $__currentLoopData = $teknisi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

            <tr>

                <td>
                    <?php echo e($loop->iteration); ?>

                </td>

                <td>

                    <strong>
                        <?php echo e($item->nama_teknisi); ?>

                    </strong>

                </td>

                <td>

                    <?php echo e($item->email ?? '-'); ?>


                </td>

                <td>

                    <?php echo e($item->nomor_telepon ?? '-'); ?>


                </td>

                <td>

                    <?php if($item->status_teknisi == 'aktif'): ?>

                        <span class="badge-active">
                            Aktif
                        </span>

                    <?php else: ?>

                        <span class="badge-nonactive">
                            Nonaktif
                        </span>

                    <?php endif; ?>

                </td>

                <td>

                    <div class="action-buttons">

                        <a href="<?php echo e(route('teknisi.edit', $item->id_teknisi)); ?>"
                           class="btn-edit">

                            Edit

                        </a>

                        <form action="<?php echo e(route('teknisi.destroy', $item->id_teknisi)); ?>"
                              method="POST">

                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>

                            <button type="submit"
                                    class="btn-delete"
                                    onclick="return confirm('Hapus teknisi ini?')">

                                Hapus

                            </button>

                        </form>

                    </div>

                </td>

            </tr>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

            <tr>

                <td colspan="6"
                    class="text-secondary">

                    Data teknisi kosong

                </td>

            </tr>

            <?php endif; ?>

        </tbody>

    </table>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\vesca_baru\resources\views/backend/teknisi/index.blade.php ENDPATH**/ ?>