<?php $__env->startSection('content'); ?>

<link rel="stylesheet" href="<?php echo e(asset('css/admin-layanan.css')); ?>">

<div class="al-header">
    <h1>Konsultasi Teknis</h1>
</div>

<?php if(session('success')): ?>
    <div class="al-alert-success"><?php echo e(session('success')); ?></div>
<?php endif; ?>


<div class="al-chips">

    <a href="<?php echo e(route('admin.konsultasi.index', ['q' => $cari ?: null])); ?>"
       class="al-chip <?php echo e(!$status ? 'active' : ''); ?>">
        Semua (<?php echo e($jumlah->sum()); ?>)
    </a>

    <?php $__currentLoopData = \App\Models\KonsultasiTeknis::STATUS; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kode => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a href="<?php echo e(route('admin.konsultasi.index', ['status' => $kode, 'q' => $cari ?: null])); ?>"
           class="al-chip <?php echo e($status === $kode ? 'active' : ''); ?>">
            <?php echo e($label); ?> (<?php echo e($jumlah[$kode] ?? 0); ?>)
        </a>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div>


<form class="al-search" method="GET" action="<?php echo e(route('admin.konsultasi.index')); ?>">

    <?php if($status): ?>
        <input type="hidden" name="status" value="<?php echo e($status); ?>">
    <?php endif; ?>

    <input type="text" name="q" value="<?php echo e($cari); ?>"
           placeholder="Cari nomor, nama, perusahaan, atau email">

    <button type="submit" class="al-btn al-btn-dark">Cari</button>

</form>

<div class="al-table-card">

    <table class="al-table">

        <thead>
            <tr>
                <th>No. Konsultasi</th>
                <th>Pengirim</th>
                <th>Kapal</th>
                <th>Kondisi Air</th>
                <th>Status</th>
                <th>Diterima</th>
                <th>Aksi</th>
            </tr>
        </thead>

        <tbody>

            <?php $__empty_1 = true; $__currentLoopData = $konsultasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>

                    <td><strong><?php echo e($item->nomor_konsultasi); ?></strong></td>

                    <td>
                        <?php echo e($item->nama_pengirim); ?>

                        <span class="al-sub"><?php echo e($item->nama_perusahaan ?: '-'); ?></span>
                    </td>

                    <td>
                        <?php echo e($item->jenis_kapal); ?>

                        <?php if($item->ukuran_kapal): ?>
                            <span class="al-sub"><?php echo e($item->ukuran_kapal); ?></span>
                        <?php endif; ?>
                    </td>

                    <td><?php echo e($item->kondisi_air_label); ?></td>

                    <td>
                        <?php [$bg, $fg] = $item->status_warna; ?>
                        <span class="al-badge" style="background:<?php echo e($bg); ?>; color:<?php echo e($fg); ?>;">
                            <?php echo e($item->status_label); ?>

                        </span>
                    </td>

                    <td><?php echo e($item->created_at->format('d M Y')); ?></td>

                    <td>
                        <a href="<?php echo e(route('admin.konsultasi.show', $item->id_konsultasi)); ?>"
                           class="al-btn al-btn-sm">
                            <i class="ri-eye-line"></i> Detail
                        </a>

                        <form action="<?php echo e(route('admin.konsultasi.destroy', $item->id_konsultasi)); ?>"
                              method="POST" style="display:inline-block;"
                              onsubmit="return confirm('Yakin hapus konsultasi ini?')">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="al-btn al-btn-sm al-btn-red">Hapus</button>
                        </form>
                    </td>

                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="7" class="al-empty">Belum ada pertanyaan konsultasi.</td>
                </tr>
            <?php endif; ?>

        </tbody>

    </table>

</div>

<div class="al-pager">
    <?php echo e($konsultasi->links('pagination::bootstrap-4')); ?>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\vesca_baru\resources\views/backend/konsultasi/index.blade.php ENDPATH**/ ?>