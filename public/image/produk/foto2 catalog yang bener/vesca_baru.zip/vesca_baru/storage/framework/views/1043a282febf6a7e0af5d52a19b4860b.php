<?php $__env->startSection('content'); ?>

<link rel="stylesheet" href="<?php echo e(asset('css/admin-layanan.css')); ?>">

<div class="al-header">
    <h1>Permintaan Penawaran</h1>
</div>

<?php if(session('success')): ?>
    <div class="al-alert-success"><?php echo e(session('success')); ?></div>
<?php endif; ?>


<div class="al-chips">

    <a href="<?php echo e(route('admin.penawaran.index', ['q' => $cari ?: null])); ?>"
       class="al-chip <?php echo e(!$status ? 'active' : ''); ?>">
        Semua (<?php echo e($jumlah->sum()); ?>)
    </a>

    <?php $__currentLoopData = \App\Models\PermintaanPenawaran::STATUS; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kode => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a href="<?php echo e(route('admin.penawaran.index', ['status' => $kode, 'q' => $cari ?: null])); ?>"
           class="al-chip <?php echo e($status === $kode ? 'active' : ''); ?>">
            <?php echo e($label); ?> (<?php echo e($jumlah[$kode] ?? 0); ?>)
        </a>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div>


<form class="al-search" method="GET" action="<?php echo e(route('admin.penawaran.index')); ?>">

    <?php if($status): ?>
        <input type="hidden" name="status" value="<?php echo e($status); ?>">
    <?php endif; ?>

    <input type="text" name="q" value="<?php echo e($cari); ?>"
           placeholder="Cari nomor, nama, perusahaan, atau email">

    <button type="submit" class="al-btn al-btn-dark">Cari</button>

</form>

<div class="al-table-card">

    <table class="al-table">

        <thead>
            <tr>
                <th>No. Permintaan</th>
                <th>Pemohon</th>
                <th>Kebutuhan</th>
                <th>Jumlah</th>
                <th>Lokasi Kirim</th>
                <th>Status</th>
                <th>Diterima</th>
                <th>Aksi</th>
            </tr>
        </thead>

        <tbody>

            <?php $__empty_1 = true; $__currentLoopData = $permintaan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>

                    <td><strong><?php echo e($item->nomor_permintaan); ?></strong></td>

                    <td>
                        <?php echo e($item->nama_pemohon); ?>

                        <span class="al-sub"><?php echo e($item->nama_perusahaan ?: '-'); ?></span>
                    </td>

                    <td>
                        <?php echo e($item->jenis_produk_label); ?>

                        <?php if($item->produk): ?>
                            <span class="al-sub"><?php echo e($item->produk->nama_produk); ?></span>
                        <?php endif; ?>
                    </td>

                    <td><?php echo e(number_format($item->jumlah, 0, ',', '.')); ?> <?php echo e($item->satuan); ?></td>

                    <td><?php echo e($item->lokasi_pengiriman); ?></td>

                    <td>
                        <?php [$bg, $fg] = $item->status_warna; ?>
                        <span class="al-badge" style="background:<?php echo e($bg); ?>; color:<?php echo e($fg); ?>;">
                            <?php echo e($item->status_label); ?>

                        </span>
                    </td>

                    <td><?php echo e($item->created_at->format('d M Y')); ?></td>

                    <td>
                        <a href="<?php echo e(route('admin.penawaran.show', $item->id_penawaran)); ?>"
                           class="al-btn al-btn-sm">
                            <i class="ri-eye-line"></i> Detail
                        </a>

                        <form action="<?php echo e(route('admin.penawaran.destroy', $item->id_penawaran)); ?>"
                              method="POST" style="display:inline-block;"
                              onsubmit="return confirm('Yakin hapus permintaan ini?')">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="al-btn al-btn-sm al-btn-red">Hapus</button>
                        </form>
                    </td>

                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="8" class="al-empty">Belum ada permintaan penawaran.</td>
                </tr>
            <?php endif; ?>

        </tbody>

    </table>

</div>

<div class="al-pager">
    <?php echo e($permintaan->links('pagination::bootstrap-4')); ?>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\vesca_baru\resources\views/backend/penawaran/index.blade.php ENDPATH**/ ?>