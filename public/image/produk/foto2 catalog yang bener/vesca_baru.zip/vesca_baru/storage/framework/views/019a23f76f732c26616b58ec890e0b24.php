

<?php $__env->startSection('content'); ?>

<link rel="stylesheet"
href="<?php echo e(asset('css/customer.css')); ?>">

<div class="page-header">

    <h1>Data Customer</h1>

    <a href="<?php echo e(route('customer.create')); ?>"
       class="btn-primary">

        + Tambah Customer

    </a>

</div>

<div class="card-table">

    <table>

        <thead>
            <tr>
                <th width="70">No</th>
                <th>Nama Customer</th>
                <th>Email</th>
                <th>Nomor Telepon</th>
                <th>Alamat</th>
                <th>Dibuat</th>
                <th width="190">Aksi</th>
            </tr>
        </thead>

        <tbody>

        <?php $__empty_1 = true; $__currentLoopData = $customer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

        <tr>

            <td>
                <strong><?php echo e($loop->iteration); ?></strong>
            </td>

            <td>

                <strong>
                    <?php echo e($item->nama_customer); ?>

                </strong>

            </td>

            <td>

                <?php if($item->email): ?>

                    <?php echo e($item->email); ?>


                <?php else: ?>

                    <span class="text-secondary">
                        Tidak ada email
                    </span>

                <?php endif; ?>

            </td>

            <td>

                <?php if($item->nomor_telepon): ?>

                    <?php echo e($item->nomor_telepon); ?>


                <?php else: ?>

                    <span class="text-secondary">
                        Tidak ada nomor
                    </span>

                <?php endif; ?>

            </td>

            <td>

                <?php if($item->alamat): ?>

                    <?php echo e($item->alamat); ?>


                <?php else: ?>

                    <span class="text-secondary">
                        Tidak ada alamat
                    </span>

                <?php endif; ?>

            </td>

            <td>

                <?php if($item->created_at): ?>

                    <?php echo e(date('d M Y', strtotime($item->created_at))); ?>   

                <?php else: ?>

                    -

                <?php endif; ?>

            </td>

            <td>

                <div class="action-buttons">

                    <a href="<?php echo e(route('customer.edit', $item->id_customer)); ?>"
                       class="btn-edit">

                        Edit

                    </a>

                    <form action="<?php echo e(route('customer.destroy', $item->id_customer)); ?>"
                          method="POST">

                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>

                        <button type="submit"
                                class="btn-delete"
                                onclick="return confirm('Hapus customer ini?')">

                            Hapus

                        </button>

                    </form>

                </div>

            </td>

        </tr>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

        <tr>

            <td colspan="7"
                style="text-align:center; padding:30px;">

                <span class="text-secondary">
                    Data customer kosong
                </span>

            </td>

        </tr>

        <?php endif; ?>

        </tbody>

    </table>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\vesca_baru\resources\views/backend/customer/index.blade.php ENDPATH**/ ?>