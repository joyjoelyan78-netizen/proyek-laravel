

<?php $__env->startSection('content'); ?>

<link rel="stylesheet"
href="/css/produk_cus.css">

<section class="detail-produk">

    <div class="container">

        <div class="detail-wrapper">

            <div class="detail-gambar">

                <?php if($produk->gambar_produk): ?>

                    <img
                        src="/storage/<?php echo e($produk->gambar_produk); ?>"
                        alt="<?php echo e($produk->nama_produk); ?>"
                    >

                <?php endif; ?>

            </div>

            <div class="detail-info">

                <span class="kategori">

                    <?php echo e($produk->kategori->nama_kategori ?? '-'); ?>


                </span>

                <h1><?php echo e($produk->nama_produk); ?></h1>

                <p>

                    <?php echo e($produk->deskripsi); ?>


                </p>

                <table class="spesifikasi">

                    <tr>
                        <td>Seri Produk</td>
                        <td><?php echo e($produk->seri_produk); ?></td>
                    </tr>

                    <tr>
                        <td>Berat</td>
                        <td><?php echo e($produk->berat); ?> Kg</td>
                    </tr>

                    <tr>
                        <td>Dimensi</td>
                        <td><?php echo e($produk->dimensi); ?></td>
                    </tr>

                    <tr>
                        <td>Standar Kualitas</td>
                        <td><?php echo e($produk->standar_kualitas); ?></td>
                    </tr>

                    <tr>
                        <td>Garansi</td>
                        <td><?php echo e($produk->masa_garansi_bulan); ?> Bulan</td>
                    </tr>

                </table>

                <?php if($produk->link_whatsapp): ?>

                    <a
                        href="<?php echo e($produk->link_whatsapp); ?>"
                        target="_blank"
                        class="btn-wa"
                    >
                        Hubungi Kami
                    </a>

                <?php endif; ?>

            </div>

        </div>

    </div>

</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\vesca_baru\resources\views/frontend/produk/produk.blade.php ENDPATH**/ ?>