<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Admin VESCA</title>

    <link rel="stylesheet" href="<?php echo e(asset('css/login.css')); ?>">

    <!-- Remix Icon -->
    <link href="https://cdn.jsdelivr.net/npm/remixicon/fonts/remixicon.css" rel="stylesheet">
</head>

<body>

<div class="login-container">

    <div class="login-box">

        <div class="login-header">
            <h1>VESCA</h1>
            <p>Admin Panel Login</p>
        </div>

        <!-- ERROR -->
        <?php if($errors->any()): ?>
            <div class="error-box">
                <?php echo e($errors->first()); ?>

            </div>
        <?php endif; ?>

        <form method="POST" action="<?php echo e(route('login')); ?>">
            <?php echo csrf_field(); ?>

            <!-- EMAIL -->
            <div class="input-group">
                <label>Email</label>

                <div class="input-icon">
                    <i class="ri-mail-line"></i>

                    <input
                        type="email"
                        name="email"
                        value="<?php echo e(old('email')); ?>"
                        placeholder="Masukkan email"
                        required
                    >
                </div>
            </div>

            <!-- PASSWORD -->
            <div class="input-group">
                <label>Password</label>

                <div class="input-icon">
                    <i class="ri-lock-line"></i>

                    <input
                        type="password"
                        name="password"
                        placeholder="Masukkan password"
                        required
                    >
                </div>
            </div>

            <!-- REMEMBER -->
            <div class="remember">
                <label>
                    <input type="checkbox" name="remember">
                    Remember me
                </label>
            </div>

            <!-- BUTTON -->
            <button type="submit" class="btn-login">
                <i class="ri-login-box-line"></i>
                Login
            </button>

        </form>

    </div>

</div>

</body>
</html><?php /**PATH C:\vesca_baru\resources\views/auth/login.blade.php ENDPATH**/ ?>